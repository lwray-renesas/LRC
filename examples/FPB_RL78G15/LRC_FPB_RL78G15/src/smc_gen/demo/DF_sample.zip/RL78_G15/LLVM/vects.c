/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2021, 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name        : vects.c
* Version          : 1.0.40
* Device(s)        : R5F12068xSP
* Description      : None
***********************************************************************************************************************/

#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"

extern void PowerON_Reset (void);

const unsigned char Option_Bytes[]  __attribute__ ((section (".option_bytes"))) = {
    0xEEU, 0xFFU, 0xF9U, 0x85U
};

const unsigned char Security_Id[]  __attribute__ ((section (".security_id"))) = {
    0x00U,0x00U,0x00U,0x00U,0x00U,0x00U,0x00U,0x00U,0x00U,0x00U
};

const unsigned char Debug_Monitor[]  __attribute__ ((section (".debug_monitor"))) = {
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
};

#define VEC          __attribute__ ((section (".vec")))
const void __near *HardwareVectors[] VEC = {
    // Address 0x0
    PowerON_Reset,
    // Secure for Debugging
    (void*)0xFFFF
};

#define VECT_SECT          __attribute__ ((section (".vects")))
const void __near *Vectors[] VECT_SECT = {
/*
 * INT_WDTI (0x4)
 */
    INT_WDTI,

/*
 * INT_P0 (0x6)
 */
    INT_P0,

/*
 * INT_P1 (0x8)
 */
    INT_P1,

/*
 * INT_P2 (0xA)
 */
    INT_P2,

/*
 * INT_P3 (0xC)
 */
    INT_P3,

/*
 * INT_P4 (0xE)
 */
    INT_P4,

/*
 * INT_P5 (0x10)
 */
    INT_P5,

/*
 * INT_CSI00/INT_IIC00/INT_ST0 (0x12)
 */
    INT_ST0,
//    INT_CSI00,
//    INT_IIC00,

/*
 * INT_CSI01/INT_IIC01/INT_SR0 (0x14)
 */
    INT_SR0,
//    INT_CSI01,
//    INT_IIC01,

/*
 * INT_SRE0 (0x16)
 */
    INT_SRE0,

/*
 * INT_TM01H (0x18)
 */
    INT_TM01H,

/*
 * INT_TM00 (0x1A)
 */
    INT_TM00,

/*
 * INT_TM01 (0x1C)
 */
    INT_TM01,

/*
 * INT_AD (0x1E)
 */
    INT_AD,

/*
 * INT_P6 (0x20)
 */
    INT_P6,

/*
 * INT_P7 (0x22)
 */
    INT_P7,

/*
 * INT_TM03H (0x24)
 */
    INT_TM03H,

/*
 * INT_IICA0 (0x26)
 */
    INT_IICA0,

/*
 * INT_TM02 (0x28)
 */
    INT_TM02,

/*
 * INT_TM03 (0x2A)
 */
    INT_TM03,

/*
 * INT_IT (0x2C)
 */
    INT_IT,

/*
 * INT_TM04 (0x2E)
 */
    INT_TM04,

/*
 * INT_TM05 (0x30)
 */
    INT_TM05,

/*
 * INT_TM06 (0x32)
 */
    INT_TM06,

/*
 * INT_TM07 (0x34)
 */
    INT_TM07,

/*
 * INT_CMP0 (0x36)
 */
    INT_CMP0,

/*
 * INT_CMP1 (0x38)
 */
    INT_CMP1,

/*
 * Padding for reserved interrupt source (0x3A)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x3C)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x3E)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x40)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x42)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x44)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x46)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x48)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x4A)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x4C)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x4E)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x50)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x52)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x54)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x56)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x58)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x5A)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x5C)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x5E)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x60)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x62)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x64)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x66)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x68)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x6A)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x6C)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x6E)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x70)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x72)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x74)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x76)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x78)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x7A)
 */
    INT_DUMMY,

/*
 * Padding for reserved interrupt source (0x7C)
 */
    INT_DUMMY,

/*
 * INT_BRK_I (0x7E)
 */
    INT_BRK_I,
};